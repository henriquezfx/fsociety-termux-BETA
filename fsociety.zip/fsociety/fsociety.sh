#!/data/data/com.termux/files/usr/bin/bash

# Configurações
VERSION="18.0"
SENHA_ACESSO="root"

# Cores
VERDE='\033[0;32m'
BRANCO='\033[1;37m'
VERMELHO='\033[0;31m'
AZUL='\033[0;34m'
CIANO='\033[0;36m'
AMARELO='\033[1;33m'
SEM_COR='\033[0m'

# --- INTERFACE ---
spinner() {
    local i sp n; sp='/-\|'; n=${#sp}
    for i in {1..15}; do printf '\b%s' "${sp:i%n:1}"; sleep 0.05; done; printf '\b'
}

loading() {
    local progresso=0
    while [ $progresso -le 20 ]; do
        barra=$(printf "%${progresso}s" | tr ' ' '█')
        percentual=$(( $progresso * 5 ))
        [ $percentual -lt 40 ] && cor=$VERMELHO || { [ $percentual -lt 80 ] && cor=$AMARELO || cor=$VERDE; }
        echo -ne "\r${BRANCO}[${cor}${barra}${SEM_COR}"
        printf "%$((20 - $progresso))s" " "
        echo -ne "${BRANCO}] ${percentual}%${SEM_COR}"
        progresso=$((progresso + 1)); sleep 0.05
    done
    echo -e "\n"
}

banner() {
    clear
    echo -e "${VERMELHO}"
    echo "  ███████╗███████╗ ██████╗  ██████╗██╗███████╗████████╗██╗   ██╗"
    echo "  ██╔════╝██╔════╝██╔═══██╗██╔════╝██║██╔════╝╚══██╔══╝╚██╗ ██╔╝"
    echo "  █████╗  ███████╗██║   ██║██║     ██║█████╗     ██║    ╚████╔╝ "
    echo "  ██╔══╝  ╚════██║██║   ██║██║     ██║██╔══╝     ██║     ╚██╔╝  "
    echo "  ██║     ███████║╚██████╔╝╚██████╗██║███████╗   ██║      ██║   "
    echo "  ╚═╝     ╚══════╝ ╚═════╝  ╚═════╝╚═╝╚══════╝   ╚═╝      ╚═╝   "
    echo -e "${BRANCO}      Desenvolvida por: ${VERMELHO}Fsociety hacking${SEM_COR}"
    echo -e "${AMARELO}      [!] VERSION $VERSION | CRYPTO DECODER ACTIVE [!]${SEM_COR}"
    echo "----------------------------------------------------------------"
}

# --- NOVA FUNÇÃO 10: HASH DECRYPTER (MD5/SHA1) ---
decrypt_hash() {
    banner
    echo -e "${AZUL}[*] Suporta: MD5, SHA1, SHA256...${SEM_COR}"
    echo -ne "${CIANO}Cole a Hash aqui: ${SEM_COR}"; read hash_val
    echo -e "${AZUL}[*] Consultando bases de dados globais...${SEM_COR}"
    loading
    # Consulta via API pública de quebra de hashes
    resultado=$(curl -s "https://md5decrypt.net/Api/api.php?hash=$hash_val&hash_type=md5&email=test@test.com&code=1a2b3c4d5e6f")
    
    if [ ! -z "$resultado" ]; then
        echo -e "${VERDE}[+] RESULTADO ENCONTRADO: $resultado${SEM_COR}"
    else
        echo -e "${VERMELHO}[!] Hash não encontrada nas tabelas comuns.${SEM_COR}"
    fi
    echo -e "\n${BRANCO}Pressione Enter...${SEM_COR}"
    read
}

# --- SISTEMA ---
banner
echo -e "${AZUL}[*] Checking System Integrity...${SEM_COR}"; spinner
echo -ne "${BRANCO}Senha: ${SEM_COR}"; stty -echo; read p; stty echo; echo ""
[ "$p" != "$SENHA_ACESSO" ] && exit

while true; do
    banner
    echo -e "${AZUL}[ 1 ]${BRANCO} Decifrar Hash (MD5/SHA1)"
    echo -e "${AZUL}[ 2 ]${BRANCO} DNS Lookup (Registros MX)"
    echo -e "${AZUL}[ 3 ]${BRANCO} Anonymous Mailer"
    echo -e "${AZUL}[ 4 ]${BRANCO} Analisar Segurança (Headers)"
    echo -e "${AZUL}[ 5 ]${BRANCO} Encurtador de URL"
    echo -e "${AZUL}[ 6 ]${BRANCO} Admin Panel Finder"
    echo -e "${AZUL}[ 7 ]${BRANCO} Extrair Links de Site"
    echo -e "${AZUL}[ 8 ]${BRANCO} Scanner Nmap"
    echo -e "${AZUL}[ 9 ]${BRANCO} Localizar IP"
    echo -e "${AZUL}[ 0 ]${BRANCO} Sair"
    echo "----------------------------------------------------------------"
    echo -ne "${VERDE}f_society > ${SEM_COR}"; read op

    case $op in
        1) decrypt_hash ;;
        2) banner; echo -ne "Domínio: "; read d; curl -s "https://api.hackertarget.com/dnslookup/?q=$d"; read ;;
        3) banner; echo -ne "Para: "; read p; echo -ne "MSG: "; read m; curl -s -X POST https://www.emkei.cz/ -d "to=$p" -d "text=$m" -d "send=1"; echo "Ok."; read ;;
        4) banner; echo -ne "URL: "; read u; curl -I -s "$u"; read ;;
        5) banner; echo -ne "URL: "; read u; curl -s "https://is.gd/create.php?format=simple&url=$u"; read ;;
        6) banner; echo -ne "Site: "; read s; pastas=("admin/" "login/"); for p in "${pastas[@]}"; do res=$(curl -s -o /dev/null -w "%{http_code}" "$s/$p"); [ "$res" == "200" ] && echo -e "${VERDE}[+] $s/$p${SEM_COR}"; done; read ;;
        7) banner; echo -ne "URL: "; read u; curl -s "$u" | grep -oE 'href="([^"#]+)"' | cut -d'"' -f2; read ;;
        8) banner; echo -ne "Alvo: "; read alvo; nmap -F -sV $alvo; read ;;
        9) banner; echo -ne "IP: "; read ip; curl -s "http://ip-api.com/json/$ip" | python3 -m json.tool; read ;;
        0) exit ;;
    esac
done
